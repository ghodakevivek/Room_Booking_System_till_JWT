package com.example.roombooking.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminLoginDTO {

	@NotBlank
	private String adminUserName;
	@NotNull
	private String adminPassword;
}
