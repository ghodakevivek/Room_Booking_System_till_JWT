package com.example.roombooking.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RoomDTO {

	@NotBlank
	private String roomNumber;
	@NotBlank
	private String roomType;
	@NotBlank
	private int roomPrice;
	@Max(2)
	private int roomBeds;
	private String roomDesc;
}
