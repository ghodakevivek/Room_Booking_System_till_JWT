package com.example.roombooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoomBookingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoomBookingSystemApplication.class, args);
	}

}
