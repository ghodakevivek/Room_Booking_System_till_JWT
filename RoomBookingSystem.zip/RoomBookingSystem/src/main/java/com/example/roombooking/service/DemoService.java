package com.example.roombooking.service;

import com.example.roombooking.entity.Demo;

public interface DemoService {

	public Demo login(String demoUsername, String demoPassword);
}
