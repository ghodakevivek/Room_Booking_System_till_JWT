package com.example.roombooking.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.roombooking.dao.PaymentRepository;
import com.example.roombooking.entity.Payment;
import com.example.roombooking.model.PaymentDTO;
import com.example.roombooking.service.PaymentService;
import com.example.roombooking.util.PaymentConverter;


@Service
public class PaymentServiceImpl implements PaymentService{

	@Autowired
	private PaymentRepository paymentRepository;
	
	@Autowired
	private PaymentConverter paymentConverter;
	
	
	@Override
	public PaymentDTO createPayment(Payment payment)
	{
		Payment p=paymentRepository.save(payment);
		return paymentConverter.convertToPaymentDTO(p);
	}
	
	
	@Override
	public List<PaymentDTO> getAllPayments()
	{
		List<Payment> payment=paymentRepository.findAll();
		
		//List of type DTO
		List<PaymentDTO> dtoList=new ArrayList<>();
		for(Payment p: payment)
		{
			dtoList.add(paymentConverter.convertToPaymentDTO(p));
		}
		return dtoList;
	}
	
	
	@Override
	public PaymentDTO getPaymentById(int id)
	{
		Payment p=paymentRepository.findById(id).get();
		return paymentConverter.convertToPaymentDTO(p);
		
	}
	
	
	@Override
	public PaymentDTO updatePayment(int id, Payment payment)
	{
		Payment p=paymentRepository.findById(id).get();
		p.setPaymentAmount(payment.getPaymentAmount());
		p.setPaymentAddress(payment.getPaymentAddress());
		p.setPaymentDesc(payment.getPaymentDesc());
		p.setUser(payment.getUser());
	
	
				
		Payment pm=paymentRepository.save(p);
		return paymentConverter.convertToPaymentDTO(pm);
	}
	
	
	@Override
	public String deletePayment(int id)
	{
		paymentRepository.deleteById(id);
		return "Payment got deleted successfully";
	}
}
