package com.example.roombooking.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.roombooking.entity.AdminLogin;
import com.example.roombooking.model.AdminLoginDTO;
import com.example.roombooking.service.AdminLoginService;
import com.example.roombooking.util.AdminLoginConverter;

@RestController
@RequestMapping("/api/adminLogin")
public class AdminLoginController {

	@Autowired
	private AdminLoginService adminLoginService;
	
	@Autowired
	private AdminLoginConverter adminLoginConverter;
	
	
	@PostMapping("/create")
	ResponseEntity <AdminLoginDTO> createAdminLogin (@Valid @RequestBody AdminLoginDTO adminLoginDto)
	{
		final AdminLogin adminLogin=adminLoginConverter.convertToAdminLoginEntity(adminLoginDto);
		return new ResponseEntity<AdminLoginDTO>(adminLoginService.createAdminLogin(adminLogin), HttpStatus.CREATED);
	}
	
	@GetMapping("/getAll")
	List<AdminLoginDTO> getAllAdminLogins()
	{
		return adminLoginService.getAllAdminLogins();
	}
	
	
	@GetMapping("/get/{id}")
	AdminLoginDTO getAdminLoginById(@PathVariable ("id")int id)
	{
		return adminLoginService.getAdminLoginById();
	}
	
	@PutMapping("/update/{id}")
	AdminLoginDTO updateAdminLogin(@Valid @PathVariable int id, @RequestBody AdminLoginDTO adminLoginDto)
	{
		final AdminLogin adminLogin=adminLoginConverter.convertToAdminLoginEntity(adminLoginDto);
		return adminLoginService.updateAdminLogin(id, adminLogin);
				
	}
	
	@DeleteMapping("/delete/{id}")
	String deleteAdminLogin(@PathVariable int id)
	{
		return adminLoginService.deleteAdminLogin(id);
	}
}
