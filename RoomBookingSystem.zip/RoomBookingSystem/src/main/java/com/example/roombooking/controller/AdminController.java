package com.example.roombooking.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.roombooking.entity.Admin;
import com.example.roombooking.model.AdminDTO;
import com.example.roombooking.service.AdminService;
import com.example.roombooking.util.AdminConverter;


@RestController
@RequestMapping("/api/admin")
public class AdminController {

	@Autowired
	private AdminService adminService;
	
	@Autowired
	private AdminConverter adminConverter;
	
	
	@PostMapping("/create")
	ResponseEntity <AdminDTO> createAdmin (@Valid @RequestBody AdminDTO adminDto)
	{
		final Admin admin=adminConverter.convertToAdminEntity(adminDto);
		return new ResponseEntity<AdminDTO>(adminService.createAdmin(admin), HttpStatus.CREATED);
		
	}
	
	@GetMapping("/getAll")
	List<AdminDTO> getAllAdmins()
	{
		return adminService.getAllAdmins();
	}
	
	
	@GetMapping("/get/{id}")
	AdminDTO getAdminById(@PathVariable ("id")int id)
	{
		return adminService.getAdminById();
	}
	
	@PutMapping("/update/{id}")
	AdminDTO updateAdmin(@Valid @PathVariable int id, @RequestBody AdminDTO adminDto)
	{
		final Admin admin=adminConverter.convertToAdminEntity(adminDto);
		return adminService.updateAdmin(id, admin);
				
	}
	
	@DeleteMapping("/delete/{id}")
	String deleteAdmin(@PathVariable int id)
	{
		return adminService.deleteAdmin(id);
	}
}
