package com.example.roombooking.model;

import java.util.List;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.example.roombooking.entity.Booking;
import com.example.roombooking.entity.Payment;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDTO {

	@NotNull
	private String userFirstName;
	@NotNull
	private String userLastName;
	@Size(min=12, max=12)
	private String userAadhar;
	@NotBlank
	private String userCity;
	private String userCountry;
	@Size(min=10, max=10)
	private String userMobile;
	@NotBlank
	private String userAddress;
	@Email
	private String userEmail;
	@NotNull
	private String userUserName;
	@NotNull
	private String userPassword;
	
	private List<Payment> payments;
	private List<Booking> bookings;
}
