package com.example.roombooking.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminDTO {
	
	@NotNull(message="Please enter admins first name")
	private String adminFirstName;
	
	@NotNull(message="Please enter admins last name")
	private String adminLastName;
	
	@Size(min=10,max=10)
	private String adminMobile;
	
	@Email(message="Please enter valid email")
	private String adminEmail;
	
	private String adminCountry;
	
	@NotNull(message="Please enter admins city")
	private String adminCity;
	
	@NotBlank(message="Enter admins username")
	private String adminUserName;
	
	@NotBlank(message="Enter valid password")
	private String adminPassword;
	
	@NotBlank(message="Please enter admins address")
	private String adminAddress;
}
