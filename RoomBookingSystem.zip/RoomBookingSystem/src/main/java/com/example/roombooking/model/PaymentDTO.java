package com.example.roombooking.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.example.roombooking.entity.User;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class PaymentDTO {

	@NotNull
	private int paymentAmount;
	@NotBlank
	private String paymentAddress;
	private String paymentDesc;
	
	private User user;
}
