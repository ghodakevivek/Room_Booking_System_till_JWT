package com.example.roombooking.model;

import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserLoginDTO {

	@NotNull(message="Please enter Username")
	private String userUserName;
	@NotNull(message="Please enter valid password")
	private String userPassword;
}
