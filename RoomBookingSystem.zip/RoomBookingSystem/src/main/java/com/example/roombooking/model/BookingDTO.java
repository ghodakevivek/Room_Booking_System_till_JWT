package com.example.roombooking.model;

import java.time.LocalDate;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;

import com.example.roombooking.entity.User;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class BookingDTO {

	
	@NotBlank
	private LocalDate bookingDate;
	
	private int bookingDays;
	@Max(4)
	private int bookingPersons;
	private String bookingDesc;
	
	private User user;
}
