package com.example.roombooking.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.roombooking.entity.Room;

public interface RoomRepository extends JpaRepository<Room, Integer>{

}
