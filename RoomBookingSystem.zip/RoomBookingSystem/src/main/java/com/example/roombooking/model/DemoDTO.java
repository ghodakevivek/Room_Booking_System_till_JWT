package com.example.roombooking.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DemoDTO {

	private String demoUsername;
	private String demoPassword;
	
}
