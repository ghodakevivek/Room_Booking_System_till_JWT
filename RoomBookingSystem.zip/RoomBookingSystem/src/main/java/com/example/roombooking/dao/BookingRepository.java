package com.example.roombooking.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.roombooking.entity.Booking;

public interface BookingRepository extends JpaRepository<Booking, Integer>{

}
