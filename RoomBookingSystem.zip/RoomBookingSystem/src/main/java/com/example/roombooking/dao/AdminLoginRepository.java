package com.example.roombooking.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.roombooking.entity.AdminLogin;

public interface AdminLoginRepository extends JpaRepository<AdminLogin, Integer>{

}
