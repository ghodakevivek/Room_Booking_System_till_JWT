package com.example.roombooking.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.roombooking.entity.Room;
import com.example.roombooking.model.RoomDTO;
import com.example.roombooking.service.RoomService;
import com.example.roombooking.util.RoomConverter;

@RestController
@RequestMapping("/api/room")
public class RoomController {

	@Autowired
	private RoomService roomService;
	
	@Autowired
	private RoomConverter roomConverter;
	
	
	
	@PostMapping("/create")
	ResponseEntity<RoomDTO> createRoom (@Valid @RequestBody RoomDTO roomDto)
	{
		final Room room=roomConverter.convertToRoomEntity(roomDto);
		return new ResponseEntity<RoomDTO>(roomService.createRoom(room), HttpStatus.CREATED);
	}
	
	
	@GetMapping("/getAll")
	List<RoomDTO> getAllRooms()
	{
		return roomService.getAllRooms();
	}
	
	
	@GetMapping("/get/{id}")
	RoomDTO getRoomById (@PathVariable int id)
	{
		return roomService.getRoomById(id);
	}
	
	
	@PutMapping("/update/{id}")
	RoomDTO updateRoom(@Valid @PathVariable int id, @RequestBody RoomDTO roomDto)
	{
		final Room room=roomConverter.convertToRoomEntity(roomDto);
		return roomService.updateRoom(id, room);
	}
	
	
	@DeleteMapping("/delete/{id}")
	String deleteRoom(@PathVariable int id)
	{
		return roomService.deleteRoom(id);
	}
}
