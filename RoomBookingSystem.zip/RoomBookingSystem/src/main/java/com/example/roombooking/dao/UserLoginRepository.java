package com.example.roombooking.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.roombooking.entity.UserLogin;

public interface UserLoginRepository extends JpaRepository<UserLogin, Integer>{

	
}
