package com.example.roombooking.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.roombooking.dao.AdminRepository;
import com.example.roombooking.entity.Admin;
import com.example.roombooking.model.AdminDTO;
import com.example.roombooking.service.AdminService;
import com.example.roombooking.util.AdminConverter;
@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
	private AdminConverter adminConverter;
	
	@Override
	public AdminDTO createAdmin(Admin admin)
	{
		Admin ad=adminRepository.save(admin);
		return adminConverter.convertToAdminDTO(ad);
	}
	
	
	@Override
	public List<AdminDTO> getAllAdmins(){
		List<Admin> admin=adminRepository.findAll();
		
		//list of type DTO
		List<AdminDTO> dtoList=new ArrayList<>();
		for(Admin a: admin)
		{
			dtoList.add(adminConverter.convertToAdminDTO(a));
		}
		return dtoList;
	}
	
	
	@Override
	public AdminDTO getAdminById(int id) {
		Admin a=adminRepository.findById(id).get();
		return adminConverter.convertToAdminDTO(a);
	}
	
	
	@Override
	public AdminDTO updateAdmin(int id, Admin admin) {
		Admin a=adminRepository.findById(id).get();
		a.setAdminFirstName(admin.getAdminFirstName());
		a.setAdminLastName(admin.getAdminLastName());
		a.setAdminMobile(admin.getAdminMobile());
		a.setAdminEmail(admin.getAdminEmail());
		a.setAdminCountry(admin.getAdminCountry());
		a.setAdminCity(admin.getAdminCity());
		a.setAdminUserName(admin.getAdminUserName());
		a.setAdminPassword(admin.getAdminPassword());
		a.setAdminAddress(admin.getAdminAddress());
		
		Admin ad=adminRepository.save(a);
		return adminConverter.convertToAdminDTO(ad);
	}
	
	
	@Override
	public String deleteAdmin(int id) {
		adminRepository.deleteById(id);
		return "Admin got deleted successFully";
	}


	@Override
	public AdminDTO getAdminById() {
		// TODO Auto-generated method stub
		return null;
	}

}
