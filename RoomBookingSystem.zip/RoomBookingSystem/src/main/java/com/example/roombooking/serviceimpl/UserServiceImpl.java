package com.example.roombooking.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.roombooking.dao.UserRepository;
import com.example.roombooking.entity.User;
import com.example.roombooking.model.UserDTO;
import com.example.roombooking.service.UserService;
import com.example.roombooking.util.UserConverter;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;
	
	
	@Autowired
	private UserConverter userConverter;
	
	@Override
	public UserDTO createUser(User user)
	{
		User u=userRepository.save(user);
		return userConverter.convertToUserDTO(u);
	}
	
	
	@Override
	public List<UserDTO> getAllUsers(){
		List<User> user=userRepository.findAll();
		
		//list of type DTO
		List<UserDTO> dtoList=new ArrayList<>();
		for(User u: user)
		{
			dtoList.add(userConverter.convertToUserDTO(u));
		}
		return dtoList;
	}
	
	
	@Override
	public UserDTO getUserById(int id) {
		User u=userRepository.findById(id).get();
		return userConverter.convertToUserDTO(u);
	}
	
	
	@Override
	public UserDTO updateUser(int id, User user) {
		User u=userRepository.findById(id).get();
		u.setUserFirstName(user.getUserFirstName());
		u.setUserLastName(user.getUserLastName());
		u.setUserAadhar(user.getUserAadhar());
		u.setUserCity(user.getUserCity());
		u.setUserCountry(user.getUserCountry());
		u.setUserMobile(user.getUserMobile());
		u.setUserAddress(user.getUserAddress());
		u.setUserUserName(user.getUserUserName());
		u.setUserPassword(user.getUserPassword());
		u.setUserEmail(user.getUserEmail());
		
		
		User ur=userRepository.save(u);
		return userConverter.convertToUserDTO(ur);
	}
	
	
	@Override
	public String deleteUser(int id) {
		userRepository.deleteById(id);
		return "User got deleted successFully";
	}


	@Override
	public UserDTO getUserById() {
		// TODO Auto-generated method stub
		return null;
	}


	
}
